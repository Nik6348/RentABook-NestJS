import { Body, Controller, Post } from '@nestjs/common';
import Stripe from 'stripe';
import { CheckoutService } from './checkout.service';
import { CreateCheckoutSessionDto } from './dto/create-checkout-session.dto';

@Controller('checkout')
export class CheckoutController {
  constructor(private readonly checkoutService: CheckoutService) {}

  @Post()
  async createCheckoutSession(@Body() createCheckoutSessionDto: CreateCheckoutSessionDto) {
    return this.checkoutService.createCheckoutSession(createCheckoutSessionDto);
  }
}