export class CreateCheckoutSessionDto {
    items: {
      title: string;
      cover: string;
      price: string;
    }[];
    userId: string;
  }