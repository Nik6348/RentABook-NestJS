import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import mongoose, { Document } from 'mongoose';

@Schema({ timestamps: true })
export class Rental extends Document {
  @Prop({ type: mongoose.Schema.Types.ObjectId, required: true, ref: 'User' })
  userId: mongoose.Schema.Types.ObjectId;

  @Prop({ type: mongoose.Schema.Types.ObjectId, required: true, ref: 'Book' })
  bookId: mongoose.Schema.Types.ObjectId;

  @Prop({ type: String, enum: ['WEEK', 'MONTH', 'LIFETIME'], required: true })
  rentalPeriod: 'WEEK' | 'MONTH' | 'LIFETIME';

  @Prop({ type: Date, default: Date.now })
  rentalDate: Date;

  @Prop({ type: Date, required: true })
  expireDate: Date;

  @Prop({ type: String, enum: ['ONGOING', 'COMPLETED'], default: 'ONGOING' })
  status: 'ONGOING' | 'COMPLETED';
}

export const RentalSchema = SchemaFactory.createForClass(Rental);