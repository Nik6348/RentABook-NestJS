import { Injectable } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { Model } from 'mongoose';
import { Rental } from './schemas/rental.schema';

@Injectable()
export class RentalsService {
  constructor(
    @InjectModel(Rental.name) private readonly rentalsModel: Model<Rental>,
  ) {}
}
