import { Module } from '@nestjs/common';
import { ConfigModule } from '@nestjs/config';
import { AppController } from './app.controller';
import { AppService } from './app.service';
import { DatabaseModule } from './database.module';
import { BooksModule } from './books/books.module';
import { CheckoutModule } from './checkout/checkout.module';
import { UsersModule } from './users/users.module';
import { RentalsModule } from './rentals/rentals.module';

@Module({
  imports: [
    ConfigModule.forRoot(
      {
        isGlobal: true,
        envFilePath:'.env',
      }
    ),
    DatabaseModule,
    BooksModule,
    CheckoutModule,
    UsersModule,
    RentalsModule,
  ],
  controllers: [AppController],
  providers: [AppService],
})
export class AppModule {}