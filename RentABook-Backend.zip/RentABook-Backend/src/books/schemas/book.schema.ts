import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import mongoose, { Document } from 'mongoose';

@Schema({ timestamps: true })
export class Book extends Document {
  @Prop({ type: String, required: true, trim: true })
  title: string;

  @Prop({ type: String, required: true, trim: true })
  author: string;

  @Prop({ type: String, required: true, trim: true })
  description: string;

  @Prop({ type: String, required: true })
  cover: string;

  @Prop({
    type: {
      week: { type: String, required: true },
      month: { type: String, required: true },
      lifetime: { type: String, required: true },
    },
    required: true,
  })
  price: {
    week: string;
    month: string;
    lifetime: string;
  };

  @Prop({ type: Date, required: true })
  publicationDate: Date;

  @Prop({ type: Number, required: true })
  pages: number;

  @Prop({ type: [String], required: true })
  genres: string[];

  @Prop({ type: Number, required: true })
  rating: number;

  @Prop([
    {
      userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
      rating: { type: Number, required: true },
    },
  ])
  ratings: {
    userId: mongoose.Schema.Types.ObjectId;
    rating: number;
  }[];

  @Prop([
    {
      userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
      review: { type: String, required: true },
    },
  ])
  reviews: {
    userId: mongoose.Schema.Types.ObjectId;
    review: string;
  }[];

  @Prop([{ type: mongoose.Schema.Types.ObjectId, ref: 'User' }])
  boughtBy: mongoose.Schema.Types.ObjectId[];
}

export const BookSchema = SchemaFactory.createForClass(Book);

// Create a text index on the title and author fields
BookSchema.index({ title: 'text', author: 'text' });





