import { Inject, Injectable, NotFoundException } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { Model } from 'mongoose';
import { Book } from './schemas/book.schema';
import { CreateBookDto } from './dto/create-book.dto';
import { UpdateBookDto } from './dto/update-book.dto';
// import { RedisClientType } from 'redis';

@Injectable()
export class BooksService {
  constructor(@InjectModel(Book.name) private readonly bookModel: Model<Book>){}
  async create(createBookDto: CreateBookDto): Promise<Book> {
    const newBook = new this.bookModel(createBookDto); 
    return newBook.save();
  }

  async findAll(
    page: number,
    limit: number,
  ): Promise<{ books: Book[]; totalBooks: number }> {
    const books = await this.bookModel
      .find()
      .skip((page - 1) * limit)
      .limit(limit)
      .exec();
    const totalBooks = await this.bookModel.countDocuments().exec();
    return { books, totalBooks };
  }

  async search(query: string): Promise<Book[]> {
    return await this.bookModel.find({ $text: { $search: query } }).exec();
  }

//  async findOne(id: string): Promise<Book> {
//     // Check if the book is in the cache
//     const cachedBook = await this.redisClient.get(`book:${id}`);
//     if (cachedBook) {
//       return JSON.parse(cachedBook) as Book;
//     }

//     // If not in cache, fetch from database
//     const book = await this.bookModel.findById(id).exec();
//     if (!book) {
//       throw new NotFoundException(`Book with ID ${id} not found`);
//     }

//     // Cache the result with an expiration time (1 hour)
//     await this.redisClient.set(`book:${id}`, JSON.stringify(book), {
//       EX: 3600,
//     });

//     return book;
//   }

  async update(id: string, updateBookDto: UpdateBookDto): Promise<Book> {
    const updatedBook = await this.bookModel
      .findByIdAndUpdate(id, updateBookDto, {
        new: true,
      })
      .exec();
    if (!updatedBook) {
      throw new NotFoundException(`Book with ID ${id} not found`);
    }
    return updatedBook;
  }

  async remove(id: string): Promise<Book> {
    const deletedBook = await this.bookModel.findByIdAndDelete(id).exec();
    if (!deletedBook) {
      throw new NotFoundException(`Book with ID ${id} not found`);
    }
    return deletedBook;
  }
}