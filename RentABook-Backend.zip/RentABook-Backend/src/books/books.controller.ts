import { Controller, Get, Post, Body, Param, Put, Delete, Query } from '@nestjs/common';
import { BooksService } from './books.service';
import { CreateBookDto } from './dto/create-book.dto';
import { UpdateBookDto } from './dto/update-book.dto';
import { Book } from './schemas/book.schema';

@Controller('books')
export class BooksController {
  constructor(private readonly booksService: BooksService) {}

  @Post()
  async create(@Body() createBookDto: CreateBookDto): Promise<Book> {
    return this.booksService.create(createBookDto);
  }

  @Get()
  async findAll(
    @Query('page') page: number = 1,
    @Query('limit') limit: number = 10,
  ): Promise<{ books: Book[]; totalBooks: number }> {
    return this.booksService.findAll(page, limit);
  }

  @Get('search')
  async search(@Query('query') query: string): Promise<Book[]> {
    return this.booksService.search(query);
  }

  // @Get(':id')
  // async findOne(@Param('id') id: string): Promise<Book> {
  //   return this.booksService.findOne(id);
  // }

  @Put(':id')
  async update(
    @Param('id') id: string,
    @Body() updateBookDto: UpdateBookDto,
  ): Promise<Book> {
    return this.booksService.update(id, updateBookDto);
  }

  @Delete(':id')
  async remove(@Param('id') id: string): Promise<Book> {
    return this.booksService.remove(id);
  }
}