import { Module, Logger } from '@nestjs/common';
import { MongooseModule } from '@nestjs/mongoose';
import { ConfigModule, ConfigService } from '@nestjs/config';
import mongoose from 'mongoose';

@Module({
  imports: [
    // ConfigModule.forRoot(), // Load .env file
    MongooseModule.forRootAsync({
      imports: [ConfigModule],
      useFactory: async (configService: ConfigService) => {
        const uri = configService.get<string>('MONGODB_URI');

        // // MongoDB connection event listeners
        // mongoose.connection.on('connected', () => {
        //   Logger.log('MongoDB connection established successfully', 'MongooseModule');
        // });

        // mongoose.connection.on('error', (err) => {
        //   Logger.error(`MongoDB connection error: ${err.message}`, '', 'MongooseModule');
        // });

        // Logger.log('Connecting to MongoDB', 'MongooseModule');
        return { uri };
      },
      inject: [ConfigService],
    }),
  ],
})
export class DatabaseModule {}
