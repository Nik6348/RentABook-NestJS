// import { Module, Global } from '@nestjs/common';
// import { createClient } from 'redis';

// @Global()
// @Module({
//   providers: [
//     {
//       provide: 'REDIS_CLIENT',
//       useFactory: async () => {
//         const client = createClient({
//           url: 'redis-17396.c261.us-east-1-4.ec2.redns.redis-cloud.com:17396',
//         });
//         await client.connect();
//         return client;
//       },
//     },
//   ],
//   exports: ['REDIS_CLIENT'],
// })
// export class RedisModule {}
