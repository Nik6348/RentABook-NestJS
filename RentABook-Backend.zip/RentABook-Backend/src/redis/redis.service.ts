import { Injectable, Inject } from '@nestjs/common';
import { RedisClient } from 'ioredis/built/connectors/SentinelConnector/types';

@Injectable()
export class RedisService {
  public constructor(
    @Inject('REDIS_CLIENT')
    private readonly redisClient: RedisClient,
  ) {}
}
