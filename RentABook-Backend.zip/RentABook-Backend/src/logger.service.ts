import { Injectable, LoggerService } from '@nestjs/common';
import * as winston from 'winston';
import 'winston-mongodb';

const logger = winston.createLogger({
  level: 'info',
  format: winston.format.combine(
    winston.format.timestamp(),
    winston.format.printf(({ timestamp, level, message }) => {
      return `${timestamp} [${level}]: ${message}`;
    })
  ),
  transports: [
    new winston.transports.Console(),
    new winston.transports.File({ filename: 'app.log' }),
    new winston.transports.MongoDB({
      level: 'error',
      db: 'mongodb://localhost:27017/logs',
      collection: 'log_entries',
      options: { useUnifiedTopology: true }
    })
  ]
});

@Injectable()
export class CustomLogger implements LoggerService {
  log(message: string) {
    logger.info(message);
  }

  error(message: string, trace: string) {
    logger.error(`${message} - ${trace}`);
  }

  warn(message: string) {
    logger.warn(message);
  }

  debug(message: string) {
    logger.debug(message);
  }

  verbose(message: string) {
    logger.verbose(message);
  }
}
