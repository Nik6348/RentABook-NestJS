import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import mongoose, { Document } from 'mongoose';

@Schema({ timestamps: true })
export class User extends Document {
  @Prop({ type: String, required: true, trim: true })
  username: string;

  @Prop({ type: String, required: true, unique: true, trim: true, lowercase: true })
  email: string;

  @Prop({ type: String, enum: ['USER', 'ADMIN'], default: 'USER' })
  role: string;

  @Prop([{ type: mongoose.Schema.Types.ObjectId, ref: 'Rental' }])
  rentalHistory: mongoose.Schema.Types.ObjectId[];
}

export const UserSchema = SchemaFactory.createForClass(User);
